import lec_3_my_module as пшелвон
from lec_3_my_module import попробуйизменитьа
from lec_3_my_module import factorial
print(factorial(int(input())))
print(попробуйизменитьа)
попробуйизменитьа = 10
print(попробуйизменитьа)
from ei_ti_kto import *
from ei_ti_kto import дать_пинка as пшёлвон
дать_пинка("Ты", "туда")
пшёлвон("челодой моловек", "⚰️ ")