import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation

fig, ax = plt.subplots()
anim_object, = plt.plot([], [], '-', lw=2)
plt.axis('equal')
ax.set_xlim(-25, 25)
ax.set_ylim(-25, 25)

x, y = [], []
def star(phi):
	alpha = np.arange(0, 4*np.pi, 0.01)
	x1 = np.array(x.append(12*np.cos(alpha) + 8*np.cos(1.5*alpha)))
	y1 = np.array(y.append(12*np.cos(alpha) - 8*np.cos(1.5*alpha)))
	X = (x1*np.cos(phi) - y1*np.sin(phi))
	Y = (y1*np.cos(phi) + x1*np.sin(phi))
	return X, Y

def update(frame):
	anim_object.set_data(star(frame))

anim = FuncAnimation(fig, update, frames = np.arange(0, 8*np.pi, 0.01), interval = 30)
anim.save('star.gif')
