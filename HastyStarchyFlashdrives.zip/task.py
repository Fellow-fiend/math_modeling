import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

fig, ax = plt.subplots()
anim_object, = plt.plot([], [], '.')
plt.axis('equal')
ax.set_xlim(0, 0.3)
ax.set_ylim(0, 1)
x, y = [0.1], [0.1]
def fractal(C, D, frame):
	x.append(x[frame]**2 - y[frame]**2 + C)
	y.append(2*x[frame]*y[frame]+D)
	return x, y

def update(frame):
	anim_object.set_data(fractal(0.3, 0.33, frame))
anim = FuncAnimation(fig, update, frames = 100, interval=30)
anim.save('fractal.gif')
